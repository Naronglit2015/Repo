import React from 'react'

function TestEvent ()  {

  const hdlClick = (msg,e) => {
    console.log(e.target)
    alert(msg)
  }

  return (
    <div className="test-event">
      <button onClick={(e)=>hdlClick('Good Afternoon',e)}>Click me</button>
      <hr />
      <button onClick={(e)=>{alert(e.target)}}>Click me</button>

    </div>
  )
}

export default TestEvent