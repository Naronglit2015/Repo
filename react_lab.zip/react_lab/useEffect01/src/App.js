import React, { useEffect, useState } from "react";
import SearchBar from "./SearchBar";

function App() {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    console.log("App : useEffect");
    setIsLoading(true)
    fetch("https://dummyjson.com/products")
      .then((resp) => resp.json())
      .then((dat) => {
        console.log(dat);
        setData(dat);
        setIsLoading(false)
      });
  }, []);

  if(isLoading) {
    return (
      <h1>Loading...</h1>
    )
  }

  if (!isLoading) {
    return (
      <div className="app">
        {console.log("JSX App...")}
        <h1>Example Search bar</h1>
        <button onClick={() => setOpen(!open)}>Search Bar</button>
        {open && <SearchBar />}
        <ul>
          {data.products.map((el) => (
            <li>
              {el.title} | {el.price}
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default App;
