import React,{useEffect, useState} from 'react'

export default function ProductList(props) {
  const { searchText } = props
  const [data, setData] = useState({})

  useEffect( ()=>{
    fetch('https://dummyjson.com/products/search?q=' + searchText)
    .then( resp => resp.json())
    .then( rs => {
      setData(rs)
    })
  }, [searchText] )


// ให้ทำ search จากช่อง input แล้วแสดงรายการตามเงื่อนไขได้
// ให้ทำ search debounce : delay input ประมาณ 1 วินาทีค่อยส่ง request (15:50)

  return (
    <div className="product-list">
      <ul>
        { data.products?.map( el => (
          <li key={el.id}> {el.title}, {el.price}</li>
        )) }
      </ul>
    </div>
  )
}