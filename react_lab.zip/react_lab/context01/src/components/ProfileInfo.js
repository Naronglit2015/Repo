import React,{useContext} from 'react'
import UserContext from '../contexts/UserContext'

function ProfileInfo() {
  const {user} = useContext(UserContext)
  return (
    <div>
      <h1>Hello, {user.firstName}</h1>
    </div>
  )
}

export default ProfileInfo