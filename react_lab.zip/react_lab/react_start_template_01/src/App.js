import React from "react";

function App() {
  return (
    <>
      <h1>Hello React, Codecamp Academy 01</h1>
    </>
  )
};

export default App;
