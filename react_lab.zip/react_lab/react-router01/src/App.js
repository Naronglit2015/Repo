import React from "react";
import AppRouter from "./AppRouter";
import AppRouterNew from "./AppRouterNew";

function App() {
  return (
    <>
      {/* <AppRouter /> */}
      <AppRouterNew />
    </>
  )
};

export default App;
