import React from 'react'

function Private() {
  return (
    <div>
      <h1>Private for user only</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum quisquam illo nobis rem consequatur commodi deleniti laboriosam exercitationem ex. Corporis aspernatur dolores ut perferendis eius quisquam voluptate quis, qui ipsa!</p>
    </div>
  )
}

export default Private