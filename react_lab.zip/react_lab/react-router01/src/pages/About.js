import React from 'react'

function About() {
  return (
    <div>
      <h1>About page</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt quae, commodi nihil libero iure est. Illum suscipit error, reprehenderit nam quam repellendus natus cupiditate sequi, dolorum, soluta officiis rerum facere!</p>
    </div>
  )
}

export default About