import React from "react";
import ParentComponent from "./ParentComponent";

export default function App() {
  return (
    <>
      <ParentComponent name="andy">
        <h1>Codecamp</h1>
        <p>This is a book.</p>
      </ParentComponent>
    </>
  )
};

// export default App
