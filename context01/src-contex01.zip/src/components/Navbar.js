import React from 'react'
import ProfileInfo from './ProfileInfo'

function Navbar(props) {
  return (
    <div>
      <ProfileInfo />
    </div>
  )
}

export default Navbar